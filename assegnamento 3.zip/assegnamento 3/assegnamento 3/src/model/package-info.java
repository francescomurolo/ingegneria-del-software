/**
 * Contains the object classes of the Wine Shop.
 */
package model;