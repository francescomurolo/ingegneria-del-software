/**
 * Server classes.
 */
package server;