/**
 * Classes used for the communication between Client and Server.
 */
package socketClasses;